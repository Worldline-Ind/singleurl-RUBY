module Paynimo
 module Version
  # Version constant for the Paynimo plugin.  
  VERSION = "1.0"
 end
end
