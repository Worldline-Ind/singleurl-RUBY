Command to create gem file
gem build paynimo.gemspec